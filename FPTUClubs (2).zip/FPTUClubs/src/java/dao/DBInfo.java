
package dao;

public interface DBInfo {
    String dbUrl = "jdbc:sqlserver://localhost:1433;databaseName=FPTUClubs";
    String dbUser = "minhdq";
    String dbPass = "123";
    String dbDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
}
